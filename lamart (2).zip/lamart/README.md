# LA MART store
Python 3 only (no packages to install). Files: server.py (backend + database setup/migrations + 12 demo products), index.html (storefront + admin), assets/ (demo product, category and hero images), uploads/ (photos you upload).

## Run
ADMIN_PASSWORD=yourpassword python3 server.py   -> http://localhost:8000
Admin: http://localhost:8000/#/admin  (user: admin). If ADMIN_PASSWORD is not set, a random password is printed once in the console.
Forgot it? Start once with RESET_ADMIN=1 ADMIN_PASSWORD=newpassword.

## Environment variables
ADMIN_PASSWORD, BASE_URL, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, PORT (optional), DB and UPLOAD_DIR (optional, for persistent storage). See .env.example.

## Add products
Admin > Add product: name, descriptions, category, prices, stock, variants (Size:S,M,L; Color:Black,Beige), images, and the Featured / Trending / New toggles. Orders and status changes are on the same dashboard.

## Stripe (test mode)
1. Stripe Dashboard > Developers > API keys: copy the sk_test_... secret key into STRIPE_SECRET_KEY.
2. Add a webhook endpoint BASE_URL/api/stripe-webhook for events checkout.session.completed and checkout.session.expired; copy its signing secret (whsec_...) into STRIPE_WEBHOOK_SECRET.
3. Locally: stripe listen --forward-to localhost:8000/api/stripe-webhook (it prints a whsec_ for local use), set BASE_URL=http://localhost:8000.
4. Pay with test card 4242 4242 4242 4242. Orders turn "paid" only when Stripe's signed webhook arrives.

## Deploy
Needs HTTPS and a persistent disk. Docker: docker build -t lamart . && docker run -p 8000:8000 -v lamart-data:/data -e BASE_URL=https://your-domain.com -e ADMIN_PASSWORD=... -e STRIPE_SECRET_KEY=... -e STRIPE_WEBHOOK_SECRET=... lamart
On Render/Railway/Fly: deploy this folder with the Dockerfile, attach a disk mounted at /data, add the variables above. Back up /data regularly.
Demo images ship inside the app (assets/), so they load even on an empty disk. The 12 demo products are created once on first start; if you delete them they will not come back.
