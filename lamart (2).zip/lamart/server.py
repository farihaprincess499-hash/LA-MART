import http.server,sqlite3,json,os,hashlib,secrets,hmac,time,base64,urllib.request,urllib.parse,re,mimetypes
D=os.path.dirname(os.path.abspath(__file__));DB=os.environ.get('DB',D+'/lamart.db');UP=os.environ.get('UPLOAD_DIR',D+'/uploads');AS=D+'/assets';os.makedirs(UP,exist_ok=True)
for l in (open(D+'/.env') if os.path.exists(D+'/.env') else []):
    if '=' in l and not l.lstrip().startswith('#'):k,v=l.strip().split('=',1);os.environ.setdefault(k,v)
SK=os.environ.get('STRIPE_SECRET_KEY','');WH=os.environ.get('STRIPE_WEBHOOK_SECRET','');BASE=os.environ.get('BASE_URL','http://localhost:8000').rstrip('/');API=os.environ.get('STRIPE_API_BASE','https://api.stripe.com');FAILS={}
def db():
    c=sqlite3.connect(DB,timeout=20);c.row_factory=sqlite3.Row;return c
def pw(p,s):return hashlib.pbkdf2_hmac('sha256',p.encode(),s.encode(),200000).hex()
def init():
    c=db();c.executescript('''create table if not exists categories(id integer primary key,name text,slug text);
create table if not exists products(id integer primary key,name,short,description,features,category_id int,price real,sale_price real,stock int,variants,images,featured int,best int,new int);
create table if not exists orders(id integer primary key,number text,name,email,phone,country,city,address,zip,items,subtotal real,shipping real,total real,method,pay_status,status,created,session);
create table if not exists reviews(id integer primary key,product_id int,name,rating int,body,created);
create table if not exists sessions(token text,exp real);create table if not exists admin(u,h,s);create table if not exists settings(k primary key,v);''')
    if not c.execute('select 1 from admin').fetchone():
        p=os.environ.get('ADMIN_PASSWORD') or secrets.token_urlsafe(10);s=secrets.token_hex(8)
        c.execute('insert into admin values(?,?,?)',('admin',pw(p,s),s));print('ADMIN LOGIN -> user: admin  password:',p)
        for i,n in enumerate(['Beauty & Makeup','Skincare','Home & Kitchen','Fashion Accessories','Jewelry','Gadgets & Electronics','Personal Care','Trending Products']):c.execute('insert into categories(name,slug)values(?,?)',(n,re.sub('[^a-z]+','-',n.lower())))
        for k,v in{'cod':'1','ship_fee':'5','free_over':'100','currency':'usd'}.items():c.execute('insert into settings values(?,?)',(k,v))
    if os.environ.get('RESET_ADMIN')=='1' and os.environ.get('ADMIN_PASSWORD'):
        x=secrets.token_hex(8);c.execute('update admin set h=?,s=?',(pw(os.environ['ADMIN_PASSWORD'],x),x));print('Admin password reset')
    if 'trending' not in [r[1] for r in c.execute('pragma table_info(products)')]:
        c.execute('alter table products add column trending int default 0');c.execute("update products set trending=1 where category_id in (select id from categories where name='Trending Products')")
    seed(c);c.commit()

SEED=[('Structured Beige Handbag','Top-handle bag with gold lock','Elegant structured handbag in soft beige vegan leather with a polished gold clasp, roomy interior and detachable strap.','Vegan leather\nGold-tone hardware\nDetachable shoulder strap',4,89.99,64.99,18,'handbag',[],1,0,0),
('Contour & Blush Palette','9-shade neutral face palette','Silky, buildable contour, blush and highlight shades in warm neutral tones. Blends easily for day or evening looks.','9 blendable shades\nLong-wear formula\nMirror included',1,34.99,24.99,40,'palette',[],1,0,0),
('Lipstick & Brush Set','Satin lipstick with makeup brushes','A rosy-nude satin lipstick paired with soft synthetic makeup brushes for a polished everyday routine.','Comfortable satin finish\n3 brushes included\nCruelty-free bristles',1,29.99,None,60,'lipstick',[{'name':'Shade','options':['Nude Rose','Soft Berry']}],0,1,0),
('Hydrating Serum Duo','Dropper serum and moisturiser','A lightweight hydrating serum with a nourishing day cream. Suitable for most skin types.','Fragrance-light\nLightweight texture\nDropper bottle',2,39.99,29.99,35,'serum',[],0,1,0),
('Ceramic Cookware Set','Non-stick pots with wooden handles','Cream-coloured non-stick cookware with tempered glass lids and heat-safe wooden handles. Even heat, easy cleaning.','Non-stick coating\nGlass lids\nInduction compatible',3,129.99,99.99,12,'cookware',[],1,0,0),
('Gold Layered Necklace','Delicate 18k gold-plated chain','A layered gold-plated necklace with a polished pendant. Pairs with everyday and evening outfits.','18k gold plating\nAdjustable length\nGift-ready',5,44.99,32.99,25,'necklace',[{'name':'Length','options':['16 in','18 in']}],1,0,0),
('Statement Earrings Set','Gold-tone earrings and ring tray','A trio of gold-tone earrings presented on a keepsake tray. Lightweight and hypoallergenic posts.','Hypoallergenic posts\n3 pairs\nTray included',5,27.99,None,30,'earrings',[],0,0,1),
('Wireless Over-Ear Headphones','Soft cushions, long battery life','Bluetooth over-ear headphones in champagne with plush ear cushions, clear sound and up to 30 hours of playtime.','Bluetooth 5.3\nUp to 30h battery\nFoldable design',6,79.99,59.99,22,'headphones',[],1,1,0),
('Smart Watch & Earbuds Duo','Fitness watch with charging earbuds','Activity-tracking smart watch with heart-rate monitoring, plus compact wireless earbuds in a charging case.','Heart-rate monitor\nCall and message alerts\nCharging case',6,99.99,74.99,15,'smartwatch',[{'name':'Colour','options':['Black','Silver']}],0,0,1),
('Daily Body Care Essentials','Wash, lotion and accessories set','A pamper set with body wash, lotion, a comb and a shaving essential. Everything for a daily routine in one box.','Gentle formulas\nTravel-friendly sizes\nGift box',7,36.99,27.99,45,'bodycare',[],0,0,1),
('Portable Fruit Blender','USB-rechargeable blender bottle','Compact rechargeable blender for smoothies on the go. Six stainless blades and a leak-proof lid.','USB-C rechargeable\n6 blades\nBPA-free',8,39.99,29.99,28,'blender',[],0,0,1),
('Instant Film Camera','Pastel pink retro instant camera','Point-and-shoot instant camera with built-in flash and selfie mirror, ideal for parties and gifts.','Built-in flash\nSelfie mirror\nFun gift idea',8,89.99,69.99,10,'camera',[],1,1,1)]
def seed(c):
    if c.execute("select 1 from settings where k='seeded'").fetchone():return
    c.execute("replace into settings values('seeded','1')")
    if c.execute('select 1 from products').fetchone():return
    for n,sh,d,f,cat,pr,sp,st,img,v,fe,be,ne in SEED:c.execute('insert into products(name,short,description,features,category_id,price,sale_price,stock,variants,images,featured,best,new)values(?,?,?,?,?,?,?,?,?,?,?,?,?)',(n,sh,d,f,cat,pr,sp,st,json.dumps(v),json.dumps(['/uploads/demo-%s.jpg'%img]),fe,be,ne))
    c.execute('update products set trending=1 where category_id=8')
def sett(c):return{r['k']:r['v'] for r in c.execute('select * from settings')}
def prod(r):
    d=dict(r);
    for k in('variants','images'):d[k]=json.loads(d[k] or '[]')
    d['features']=[x for x in (d['features'] or '').split('\n') if x];return d
def rating(c,pid):
    r=c.execute('select avg(rating)a,count(*)n from reviews where product_id=?',(pid,)).fetchone();return round(r['a'] or 0,1),r['n']
class H(http.server.BaseHTTPRequestHandler):
    def log_message(s,*a):pass
    def hdr(s):
        for k,v in(('X-Content-Type-Options','nosniff'),('X-Frame-Options','DENY'),('Referrer-Policy','same-origin')):s.send_header(k,v)
    def chk(s,B):
        try:
            if not str(B.get('name','')).strip():return 'Product name is required'
            pr=float(B.get('price'));st=int(B.get('stock',0));sp=B.get('sale_price')
            if pr<=0 or st<0:return 'Price must be above 0 and stock cannot be negative'
            if sp and not 0<float(sp)<pr:return 'Sale price must be lower than the regular price'
        except(TypeError,ValueError):return 'Price and stock must be numbers'
    def out(s,o,code=200):
        b=json.dumps(o).encode();s.send_response(code);s.send_header('Content-Type','application/json');s.send_header('Content-Length',str(len(b)));s.hdr();s.end_headers();s.wfile.write(b)
    def body(s):
        n=int(s.headers.get('Content-Length',0))
        if n>10_000_000:raise ValueError('Request too large')
        s.raw=s.rfile.read(n);return json.loads(s.raw or '{}') if s.raw[:1] in(b'{',b'[') or not s.raw else {}
    def admin(s,c):
        t=s.headers.get('Authorization','').replace('Bearer ','');r=c.execute('select exp from sessions where token=?',(t,)).fetchone();return bool(r and r['exp']>time.time())
    def do_GET(s):s.go('GET')
    def do_POST(s):s.go('POST')
    def do_PUT(s):s.go('PUT')
    def do_DELETE(s):s.go('DELETE')
    def go(s,m):
        u=urllib.parse.urlparse(s.path);p=u.path;q={k:v[0] for k,v in urllib.parse.parse_qs(u.query).items()}
        try:
            if p.startswith('/api/'):return s.api(m,p[5:],q)
            if p.startswith('/uploads/'):
                n=os.path.basename(p);f=next((x for x in (UP+'/'+n,AS+'/'+n) if os.path.isfile(x)),'')
            else:f=D+'/index.html'
            if not f:return s.out({'error':'not found'},404)
            b=open(f,'rb').read();s.send_response(200);s.send_header('Content-Type',mimetypes.guess_type(f)[0] or 'text/html');s.send_header('Content-Length',str(len(b)));s.hdr();s.end_headers();s.wfile.write(b)
        except Exception as e:s.out({'error':str(e)},500)
    def api(s,m,p,q):
        c=db();B=s.body() if m in('POST','PUT') else {}
        if p=='stripe-webhook':
            sig=dict(x.split('=',1) for x in s.headers.get('Stripe-Signature','').split(',') if '=' in x)
            if not WH or not hmac.compare_digest(hmac.new(WH.encode(),(sig.get('t','')+'.').encode()+s.raw,'sha256').hexdigest(),sig.get('v1','')):return s.out({'error':'bad signature'},400)
            e=json.loads(s.raw)
            if e['type']=='checkout.session.completed':
                o=e['data']['object']
                if o.get('payment_status')=='paid':c.execute("update orders set pay_status='paid',status='Confirmed' where session=?",(o['id'],));c.commit()
            elif e['type']=='checkout.session.expired':s.cancel(c,session=e['data']['object']['id'])
            return s.out({'ok':1})
        if p=='health':return s.out({'ok':1})
        if p=='admin/login':
            ip=s.client_address[0];FAILS[ip]=[t for t in FAILS.get(ip,[]) if t>time.time()-900]
            if len(FAILS[ip])>=5:return s.out({'error':'Too many attempts. Try again in 15 minutes.'},429)
            a=c.execute('select * from admin').fetchone()
            if B.get('u')==a['u'] and hmac.compare_digest(pw(B.get('p',''),a['s']),a['h']):
                t=secrets.token_hex(24);c.execute('insert into sessions values(?,?)',(t,time.time()+28800));c.commit();return s.out({'token':t})
            FAILS[ip].append(time.time());return s.out({'error':'Wrong username or password'},401)
        if p.startswith('admin/'):
            if not s.admin(c):return s.out({'error':'unauthorized'},401)
            return s.adm(c,m,p[6:],B)
        if p=='settings':st=sett(c);return s.out({'cod':st['cod']=='1','card':bool(SK),'ship_fee':float(st['ship_fee']),'free_over':float(st['free_over'])})
        if p=='categories':return s.out([dict(r) for r in c.execute('select * from categories')])
        if p=='products' and m=='GET':
            w,a=['1'],[]
            if q.get('q'):w.append('(name like ? or short like ? or description like ?)');a+=['%'+q['q']+'%']*3
            if q.get('cat'):w.append('category_id=?');a.append(q['cat'])
            if q.get('min'):w.append('coalesce(sale_price,price)>=?');a.append(q['min'])
            if q.get('max'):w.append('coalesce(sale_price,price)<=?');a.append(q['max'])
            if q.get('flag') in('featured','best','new','trending'):w.append(q['flag']+'=1')
            o={'low':'coalesce(sale_price,price)','high':'coalesce(sale_price,price) desc','new':'id desc'}.get(q.get('sort'),'id desc')
            L=[]
            for r in c.execute('select * from products where '+' and '.join(w)+' order by '+o,a):
                d=prod(r);d['rating'],d['reviews']=rating(c,d['id']);L.append(d)
            return s.out(L)
        mm=re.match(r'products/(\d+)$',p)
        if mm:
            r=c.execute('select * from products where id=?',(mm[1],)).fetchone()
            if not r:return s.out({'error':'not found'},404)
            d=prod(r);d['rating'],d['reviews']=rating(c,d['id']);d['review_list']=[dict(x) for x in c.execute('select * from reviews where product_id=? order by id desc',(d['id'],))]
            d['related']=[prod(x) for x in c.execute('select * from products where category_id=? and id!=? limit 4',(d['category_id'],d['id']))];return s.out(d)
        if p=='reviews' and m=='POST':
            if not 1<=int(B.get('rating',0))<=5 or not B.get('name'):return s.out({'error':'Name and rating 1-5 required'},400)
            c.execute('insert into reviews(product_id,name,rating,body,created)values(?,?,?,?,?)',(B['product_id'],B['name'][:60],int(B['rating']),B.get('body','')[:1000],time.strftime('%Y-%m-%d')));c.commit();return s.out({'ok':1})
        if p=='order' and m=='POST':return s.order(c,B)
        if p=='order' and m=='GET':
            r=c.execute('select * from orders where number=? and lower(email)=lower(?)',(q.get('number',''),q.get('email',''))).fetchone()
            if not r:return s.out({'error':'No order found for that number and email'},404)
            d=dict(r);d['items']=json.loads(d['items']);d.pop('session');return s.out(d)
        s.out({'error':'not found'},404)
    def cancel(s,c,oid=None,session=None):
        r=c.execute('select * from orders where id=?' if oid else 'select * from orders where session=?',(oid or session,)).fetchone()
        if r and r['status']!='Cancelled':
            for i in json.loads(r['items']):c.execute('update products set stock=stock+? where id=?',(i['qty'],i['id']))
            c.execute("update orders set status='Cancelled' where id=?",(r['id'],));c.commit()
    def order(s,c,B):
        st=sett(c)
        for f in('name','email','phone','country','city','address','zip'):
            if not str(B.get(f,'')).strip():return s.out({'error':'Please fill in '+f},400)
        if B.get('method')=='cod' and st['cod']!='1':return s.out({'error':'Cash on delivery is not available'},400)
        if B.get('method')=='card' and not SK:return s.out({'error':'Card payments are not configured'},400)
        items=[];sub=0;c.execute('begin immediate')
        for it in B.get('items',[]):
            r=c.execute('select * from products where id=?',(it['id'],)).fetchone();q=int(it['qty'])
            if not r or q<1:c.rollback();return s.out({'error':'Invalid item'},400)
            if r['stock']<q:c.rollback();return s.out({'error':f"{r['name']}: only {r['stock']} left in stock"},409)
            pr=r['sale_price'] or r['price'];sub+=pr*q;items.append({'id':r['id'],'name':r['name'],'price':pr,'qty':q,'variant':it.get('variant','')})
            c.execute('update products set stock=stock-? where id=?',(q,r['id']))
        if not items:c.rollback();return s.out({'error':'Cart is empty'},400)
        ship=0 if sub>=float(st['free_over']) else float(st['ship_fee']);tot=round(sub+ship,2);num='LM-'+secrets.token_hex(3).upper()
        cur=c.execute('insert into orders(number,name,email,phone,country,city,address,zip,items,subtotal,shipping,total,method,pay_status,status,created)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(num,B['name'],B['email'],B['phone'],B['country'],B['city'],B['address'],B['zip'],json.dumps(items),sub,ship,tot,B['method'],'unpaid' if B['method']=='card' else 'cod_pending','Pending',time.strftime('%Y-%m-%d %H:%M')));oid=cur.lastrowid;c.commit()
        res={'number':num,'email':B['email']}
        if B['method']=='card':
            f=[('mode','payment'),('customer_email',B['email']),('success_url',BASE+f'/#/order/{num}?email={urllib.parse.quote(B["email"])}'),('cancel_url',BASE+'/#/cart'),('client_reference_id',num)]
            for i,it in enumerate(items+([{'name':'Shipping','price':ship,'qty':1}] if ship else [])):f+=[(f'line_items[{i}][quantity]',it['qty']),(f'line_items[{i}][price_data][currency]',st['currency']),(f'line_items[{i}][price_data][unit_amount]',round(it['price']*100)),(f'line_items[{i}][price_data][product_data][name]',it['name'])]
            try:
                rq=urllib.request.Request(API+'/v1/checkout/sessions',urllib.parse.urlencode(f).encode(),{'Authorization':'Bearer '+SK});r=json.load(urllib.request.urlopen(rq,timeout=20))
                c.execute('update orders set session=? where id=?',(r['id'],oid));c.commit();res['url']=r['url']
            except Exception as e:s.cancel(c,oid);return s.out({'error':'Payment provider error: '+str(e)},502)
        s.out(res)
    def adm(s,c,m,p,B):
        P=('name','short','description','features','category_id','price','sale_price','stock','featured','best','new','trending')
        if p=='upload':
            ext=B['name'].rsplit('.',1)[-1].lower()
            if ext not in('jpg','jpeg','png','webp','gif') or len(B['data'])>7_000_000:return s.out({'error':'Use a JPG, PNG, WEBP or GIF under 5 MB'},400)
            fn=secrets.token_hex(8)+'.'+ext;open(UP+'/'+fn,'wb').write(base64.b64decode(B['data'].split(',')[-1]));return s.out({'url':'/uploads/'+fn})
        if p.startswith('products') and m in('POST','PUT'):
            e=s.chk(B)
            if e:return s.out({'error':e},400)
        if p=='products':
            if m=='POST':
                cur=c.execute('insert into products(name,short,description,features,category_id,price,sale_price,stock,variants,images,featured,best,new,trending)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(B['name'],B.get('short',''),B.get('description',''),B.get('features',''),B.get('category_id'),B['price'],B.get('sale_price') or None,B.get('stock',0),json.dumps(B.get('variants',[])),json.dumps(B.get('images',[])),B.get('featured',0),B.get('best',0),B.get('new',0),B.get('trending',0)));c.commit();return s.out({'id':cur.lastrowid})
        mm=re.match(r'products/(\d+)$',p)
        if mm:
            if m=='PUT':
                c.execute('update products set '+','.join(k+'=?' for k in P)+',variants=?,images=? where id=?',[B.get(k) or None if k=='sale_price' else B.get(k) for k in P]+[json.dumps(B.get('variants',[])),json.dumps(B.get('images',[])),mm[1]]);c.commit();return s.out({'ok':1})
            if m=='DELETE':c.execute('delete from products where id=?',(mm[1],));c.commit();return s.out({'ok':1})
        if p=='orders':return s.out([dict(r,items=json.loads(r['items'])) for r in c.execute('select * from orders order by id desc')])
        mm=re.match(r'orders/(\d+)$',p)
        if mm and m=='PUT':
            if B['status'] not in('Pending','Confirmed','Processing','Shipped','Delivered','Cancelled'):return s.out({'error':'bad status'},400)
            if B['status']=='Cancelled':s.cancel(c,mm[1])
            else:c.execute('update orders set status=? where id=?',(B['status'],mm[1]))
            if B.get('pay_status'):c.execute('update orders set pay_status=? where id=?',(B['pay_status'],mm[1]))
            c.commit();return s.out({'ok':1})
        if p=='categories' and m=='POST':c.execute('insert into categories(name,slug)values(?,?)',(B['name'],re.sub('[^a-z]+','-',B['name'].lower())));c.commit();return s.out({'ok':1})
        mm=re.match(r'categories/(\d+)$',p)
        if mm:
            if m=='PUT':c.execute('update categories set name=? where id=?',(B['name'],mm[1]))
            else:c.execute('delete from categories where id=?',(mm[1],))
            c.commit();return s.out({'ok':1})
        if p=='settings' and m=='PUT':
            for k in('cod','ship_fee','free_over'):
                if k in B:c.execute('replace into settings values(?,?)',(k,str(B[k])))
            c.commit();return s.out({'ok':1})
        s.out({'error':'not found'},404)
if __name__=='__main__':
    init()
    if SK and BASE.startswith('http://localhost'):print('WARNING: set BASE_URL to your public https address so Stripe can return customers to the store')
    if SK and not WH:print('WARNING: set STRIPE_WEBHOOK_SECRET or card orders will never be marked paid')
    import socketserver;http.server.ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT',8000))),H).serve_forever()
